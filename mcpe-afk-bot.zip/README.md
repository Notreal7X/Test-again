# MCPE AFK Bot

1. Install Node.js
2. Run: npm install
3. Set SERVER_HOST, SERVER_PORT, BOT_NAME
4. Run: node index.js
