const bedrock = require("bedrock-protocol");

function connect() {
  const bot = bedrock.createClient({
    host: process.env.SERVER_HOST || "yourserver.aternos.me",
    port: Number(process.env.SERVER_PORT || 19132),
    username: process.env.BOT_NAME || "AFK_Bot"
  });

  bot.on("join", () => {
    console.log("Connected!");
    setInterval(() => {
      console.log("Still online...");
    },30000);
  });

  bot.on("disconnect",()=> {
    console.log("Disconnected. Reconnecting...");
    setTimeout(connect,5000);
  });

  bot.on("error",(e)=>console.log(e));
}
connect();
